package com.cauashi.flashplayer.ui

import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import com.cauashi.flashplayer.R
import com.cauashi.flashplayer.data.GameItem
import com.cauashi.flashplayer.data.RecentStore
import com.cauashi.flashplayer.databinding.ActivityMainBinding
import com.cauashi.flashplayer.player.PlayerActivity
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var recentStore: RecentStore
    private lateinit var recentAdapter: GameAdapter

    private val openSwf = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { openExternalUri(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        recentStore = RecentStore(this)

        binding.toolbar.setOnMenuItemClickListener { onMenu(it.itemId) }

        binding.openButton.setOnClickListener {
            openSwf.launch(arrayOf("application/x-shockwave-flash", "application/octet-stream", "*/*"))
        }

        setupSamples()
        setupRecent()
        handleViewIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        refreshRecent()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleViewIntent(intent)
    }

    private fun onMenu(id: Int): Boolean = when (id) {
        R.id.action_settings -> {
            startActivity(Intent(this, SettingsActivity::class.java)); true
        }
        R.id.action_about -> {
            AlertDialog.Builder(this)
                .setTitle(R.string.about_title)
                .setMessage(R.string.about_body)
                .setPositiveButton(android.R.string.ok, null)
                .show()
            true
        }
        else -> false
    }

    private fun setupSamples() {
        val samples = (assets.list("sample_files") ?: emptyArray())
            .filter { it.endsWith(".swf", ignoreCase = true) }
            .sorted()
            .map { GameItem(it.substringBeforeLast('.'), "sample_files/$it") }

        val adapter = GameAdapter(R.layout.item_game) { play(it) }
        binding.sampleGrid.layoutManager = GridLayoutManager(this, 3)
        binding.sampleGrid.adapter = adapter
        adapter.submit(samples)
    }

    private fun setupRecent() {
        recentAdapter = GameAdapter(R.layout.item_recent) { play(it) }
        binding.recentList.adapter = recentAdapter
    }

    private fun refreshRecent() {
        val recent = recentStore.list()
        recentAdapter.submit(recent)
        val empty = recent.isEmpty()
        binding.emptyRecent.visibility = if (empty) View.VISIBLE else View.GONE
        binding.recentList.visibility = if (empty) View.GONE else View.VISIBLE
    }

    private fun play(item: GameItem) {
        if (item.path.startsWith("/")) {
            recentStore.add(item)
        }
        startActivity(
            Intent(this, PlayerActivity::class.java)
                .putExtra(PlayerActivity.EXTRA_PATH, item.path)
                .putExtra(PlayerActivity.EXTRA_TITLE, item.title)
        )
    }

    private fun handleViewIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_VIEW) {
            intent.data?.let { openExternalUri(it) }
        }
    }

    /** Copies a picked/opened SWF into cache and launches the player. */
    private fun openExternalUri(uri: Uri) {
        try {
            val name = queryDisplayName(uri) ?: "game.swf"
            val title = name.substringBeforeLast('.')
            val dest = File(cacheDir, "swf").apply { mkdirs() }
                .let { File(it, "${System.currentTimeMillis()}_$name") }
            openUriStream(uri).use { input ->
                dest.outputStream().use { input.copyTo(it) }
            }
            play(GameItem(title, dest.absolutePath))
        } catch (e: Exception) {
            e.printStackTrace()
            Toast.makeText(this, R.string.error_open, Toast.LENGTH_SHORT).show()
        }
    }

    /** Opens a stream for either a content:// uri or a direct file:// path. */
    private fun openUriStream(uri: Uri): java.io.InputStream {
        if (uri.scheme == "file") {
            val p = uri.path
            if (p != null) {
                val f = File(p)
                if (f.exists()) return f.inputStream()
            }
        }
        return requireNotNull(contentResolver.openInputStream(uri))
    }

    private fun queryDisplayName(uri: Uri): String? {
        if (uri.scheme == "file") return uri.lastPathSegment
        var name: String? = null
        val cursor: Cursor? = contentResolver.query(uri, null, null, null, null)
        cursor?.use {
            val idx = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && it.moveToFirst()) name = it.getString(idx)
        }
        return name
    }
}
