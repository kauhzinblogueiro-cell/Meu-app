package com.cauashi.flashplayer.data

/**
 * @param title display name shown in the UI
 * @param path  either a relative asset path (e.g. "sample_files/Car.swf") for
 *              bundled samples, or an absolute file path for user-opened files
 */
data class GameItem(
    val title: String,
    val path: String
)
