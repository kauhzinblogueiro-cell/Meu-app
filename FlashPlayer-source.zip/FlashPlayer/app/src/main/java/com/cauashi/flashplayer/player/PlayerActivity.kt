package com.cauashi.flashplayer.player

import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.WebSettings
import android.webkit.WebView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.PreferenceManager
import com.cauashi.flashplayer.R
import com.cauashi.flashplayer.databinding.ActivityPlayerBinding
import com.cauashi.flashplayer.player.PlayerWebViewClient.Companion.VIRTUAL_BASE

/**
 * Hosts the Ruffle player inside a WebView. The system that actually runs the
 * SWF mirrors the iFlaz Player approach: load the bundled `core/player.htm`,
 * inject the SWF path into the `$FLASH_PATH$` placeholder, then serve every
 * resource locally through [PlayerWebViewClient].
 */
class PlayerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPlayerBinding
    private lateinit var path: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        path = intent.getStringExtra(EXTRA_PATH).orEmpty()
        if (path.isEmpty()) {
            finish()
            return
        }

        val prefs = PreferenceManager.getDefaultSharedPreferences(this)

        if (prefs.getBoolean("keep_screen_on", true)) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        if (prefs.getBoolean("fullscreen", true)) {
            enterFullscreen()
        }
        when (prefs.getString("flash_orientation", "auto")) {
            "portrait" -> requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
            "landscape" -> requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        }

        configureWebView(prefs.getString("background_color", "white") ?: "white")
        loadFlash()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = showExitDialog()
        })
    }

    @Suppress("SetJavaScriptEnabled")
    private fun configureWebView(bgColor: String) {
        val web = binding.webView
        web.webViewClient = PlayerWebViewClient { binding.loadingOverlay.visibility = View.GONE }
        web.settings.apply {
            javaScriptEnabled = true
            allowFileAccess = true
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(true)
            builtInZoomControls = true
            displayZoomControls = false
            cacheMode = WebSettings.LOAD_NO_CACHE
        }
        web.setBackgroundColor(if (bgColor == "black") Color.BLACK else Color.WHITE)
    }

    private fun loadFlash() {
        val template = assets.open("core/player.htm").use { it.readBytes().toString(Charsets.UTF_8) }
        val flashUrl = if (path.startsWith("/")) {
            VIRTUAL_BASE + path
        } else {
            "$VIRTUAL_BASE/assets/$path"
        }
        val html = template.replace("\$FLASH_PATH\$", flashUrl)
        binding.webView.loadDataWithBaseURL("$VIRTUAL_BASE/", html, "text/html", "UTF-8", "about:blank")
    }

    private fun enterFullscreen() {
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
    }

    private fun showExitDialog() {
        binding.webView.onPause()
        AlertDialog.Builder(this)
            .setTitle(R.string.exit_title)
            .setMessage(R.string.exit_msg)
            .setPositiveButton(R.string.action_exit) { _, _ -> finish() }
            .setNeutralButton(R.string.action_restart) { d, _ ->
                d.dismiss()
                binding.loadingOverlay.visibility = View.VISIBLE
                loadFlash()
                binding.webView.onResume()
            }
            .setNegativeButton(R.string.cancel) { d, _ ->
                d.dismiss()
                binding.webView.onResume()
            }
            .setOnCancelListener { binding.webView.onResume() }
            .show()
    }

    override fun onPause() {
        super.onPause()
        binding.webView.onPause()
    }

    override fun onResume() {
        super.onResume()
        binding.webView.onResume()
    }

    override fun onDestroy() {
        super.onDestroy()
        binding.webView.destroy()
    }

    companion object {
        const val EXTRA_PATH = "path"
        const val EXTRA_TITLE = "title"
    }
}
