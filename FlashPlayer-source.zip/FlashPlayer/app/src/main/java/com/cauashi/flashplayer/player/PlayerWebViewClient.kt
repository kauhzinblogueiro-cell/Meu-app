package com.cauashi.flashplayer.player

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.File
import java.io.FileInputStream
import java.net.URLDecoder

/**
 * Serves the Ruffle runtime and the SWF file to the WebView through a virtual
 * host. Requests to [VIRTUAL_HOST] never hit the network: anything under
 * `/assets/` is read from the bundled APK assets (Ruffle wasm/js/css and the
 * sample games), while any other absolute path is read straight from the
 * device filesystem (a user-picked .swf copied into cache).
 */
class PlayerWebViewClient(
    private val onPageReady: () -> Unit
) : WebViewClient() {

    override fun onPageFinished(view: WebView, url: String?) {
        super.onPageFinished(view, url)
        onPageReady()
    }

    private fun mimeFor(path: String): String {
        val p = path.lowercase()
        return when {
            p.endsWith(".js") -> "application/javascript"
            p.endsWith(".css") -> "text/css"
            p.endsWith(".swf") -> "application/x-shockwave-flash"
            p.endsWith(".wasm") -> "application/wasm"
            else -> "text/html"
        }
    }

    override fun shouldInterceptRequest(
        view: WebView,
        request: WebResourceRequest
    ): WebResourceResponse? {
        try {
            val uri = request.url.toString()
            if (uri.isNotEmpty()) {
                if (uri.startsWith("$VIRTUAL_BASE/assets/")) {
                    val asset = URLDecoder.decode(uri.replace("$VIRTUAL_BASE/assets/", ""), "UTF-8")
                    return WebResourceResponse(
                        mimeFor(asset),
                        "UTF-8",
                        view.context.assets.open(asset)
                    )
                }
                if (uri.startsWith(VIRTUAL_BASE)) {
                    val path = URLDecoder.decode(uri.replace(VIRTUAL_BASE, ""), "UTF-8")
                    val file = File(path)
                    if (file.exists() && file.isFile) {
                        return WebResourceResponse(
                            mimeFor(path),
                            "UTF-8",
                            FileInputStream(file)
                        )
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return super.shouldInterceptRequest(view, request)
    }

    override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
        return true
    }

    companion object {
        const val VIRTUAL_HOST = "swfplayer.com"
        const val VIRTUAL_BASE = "http://$VIRTUAL_HOST"
    }
}
