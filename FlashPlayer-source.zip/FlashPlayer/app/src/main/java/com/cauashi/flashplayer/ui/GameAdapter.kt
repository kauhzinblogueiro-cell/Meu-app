package com.cauashi.flashplayer.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.cauashi.flashplayer.R
import com.cauashi.flashplayer.data.GameItem

class GameAdapter(
    private val layoutRes: Int,
    private val onClick: (GameItem) -> Unit
) : RecyclerView.Adapter<GameAdapter.VH>() {

    private val items = ArrayList<GameItem>()

    fun submit(newItems: List<GameItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    inner class VH(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val name: TextView = view.findViewById(R.id.name)
        init {
            view.setOnClickListener {
                val pos = bindingAdapterPosition
                if (pos != RecyclerView.NO_POSITION) onClick(items[pos])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(layoutRes, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.name.text = items[position].title
    }

    override fun getItemCount(): Int = items.size
}
