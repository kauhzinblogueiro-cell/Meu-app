package com.cauashi.flashplayer.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Persists the list of recently played games in SharedPreferences as JSON. */
class RecentStore(context: Context) {

    private val prefs = context.applicationContext
        .getSharedPreferences("recent_games", Context.MODE_PRIVATE)

    fun list(): List<GameItem> {
        val raw = prefs.getString(KEY, null) ?: return emptyList()
        val arr = JSONArray(raw)
        val out = ArrayList<GameItem>(arr.length())
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val item = GameItem(o.getString("title"), o.getString("path"))
            // drop entries whose cached file no longer exists
            if (item.path.startsWith("/") && !File(item.path).exists()) continue
            out.add(item)
        }
        return out
    }

    fun add(item: GameItem) {
        val current = list().filterNot { it.path == item.path }.toMutableList()
        current.add(0, item)
        while (current.size > MAX) current.removeAt(current.size - 1)
        val arr = JSONArray()
        current.forEach {
            arr.put(JSONObject().put("title", it.title).put("path", it.path))
        }
        prefs.edit().putString(KEY, arr.toString()).apply()
    }

    companion object {
        private const val KEY = "items"
        private const val MAX = 12
    }
}
